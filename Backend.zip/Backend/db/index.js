const {Client} = require("pg");
require("dotenv").config()
console.log();
const client = new Client({
    user: process.env.DB_USER,
    database: process.env.DB_DATABASE,
    host: process.env.DB_HOST,
    password: process.env.DB_PASSWORD,
    port: 5432
});

client.connect();

module.exports = client;