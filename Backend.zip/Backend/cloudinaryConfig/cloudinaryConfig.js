import { config, uploader } from 'cloudinary';
const cloudinaryConfig = () => config({

});
export { cloudinaryConfig, uploader }